from flask import Flask,render_template,request
from joblib import dump,load
import numpy as np



app = Flask(__name__)

@app.route('/', methods=['GET','POST'])

def prediction():
    if request.method == 'POST':
        beds = request.form['bedrooms']
        baths = request.form['bathrooms']
        Floor = request.form['floors']
        sqftliving = request.form['sqft_living']
        sqftlot = request.form['sqft_lot']
        model =load("housing.joblib")
        arr=np.array([[beds,baths,Floor,sqftliving,sqftlot]])
        prediction=model.predict(arr)
        pred=prediction
        return render_template("index.html" , house_pred = pred)
    
    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True)
